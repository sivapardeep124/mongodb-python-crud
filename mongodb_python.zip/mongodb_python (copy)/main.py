import pymongo
from bson import ObjectId
from flask import *

app = Flask(__name__)
app.secret_key = 'abc'


conn = pymongo.MongoClient("mongodb://localhost:27017")

details = conn['first_db']['students']


@app.route('/',methods = ['GET','POST'])
def home():
    if request.method == 'GET':
        show = details.find()
        return render_template('homepage.html',datas = show)
    if request.method == 'POST':
        name = request.form['nam']
        email = request.form['email']
        password = request.form['pass']

        details.insert_one({'NAME' : name,'EMAIL' : email,'PASSWORD' : password})
        flash('Added Successfully')
        return redirect(url_for('home'))

@app.route('/edit/<string:id>',methods = ['GET','POST'])
def edit(id):
    if request.method == 'GET':
        res = details.find_one({'_id' : ObjectId(id)})
        return render_template('editpage.html',data = res)

    if request.method == 'POST':
        name = request.form['nam']
        email = request.form['email']
        password = request.form['pass']

        details.update({"_id":ObjectId(id)},{'$set':{"NAME":name,"EMAIL":email,"PASSWORD":password}})
        flash('Update Successfully')
        return redirect(url_for('home'))

@app.route('/delete/<string:id>',methods = ['GET','POST'])
def delete(id):
    details.delete_one({"_id" : ObjectId(id)})
    return redirect(url_for('home'))





if(__name__ == '__main__'):
    app.run(debug=True)
